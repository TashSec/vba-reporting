VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmMailChoice 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmMailChoice.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmMailChoice"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public Result As Long
Public lblInfo As MSForms.Label
Public WithEvents cmdFirst As MSForms.CommandButton
Attribute cmdFirst.VB_VarHelpID = -1
Public WithEvents cmdSecond As MSForms.CommandButton
Attribute cmdSecond.VB_VarHelpID = -1
Private WithEvents cmdCancel As MSForms.CommandButton
Attribute cmdCancel.VB_VarHelpID = -1
Private Sub UserForm_Initialize()
    Me.Caption = "Choose an action": Me.width = 470: Me.Height = 172
    Me.Font.name = "Tahoma": Me.Font.Size = 12: Me.BackColor = RGB(252, 250, 252)
    Set lblInfo = Me.Controls.Add("Forms.Label.1", "lblInfo", True)
    With lblInfo
        .Left = 18: .Top = 18: .width = 430: .Height = 48
        .Caption = "Selected email messages": .WordWrap = True
        .Font.name = "Tahoma": .Font.Size = 12
        .ForeColor = RGB(38, 50, 56): .BackColor = Me.BackColor
    End With
    Set cmdFirst = Me.Controls.Add("Forms.CommandButton.1", "cmdFirst", True)
    StyleButton cmdFirst, "&Browse files...", 18, 158, RGB(226, 240, 247)
    Set cmdSecond = Me.Controls.Add("Forms.CommandButton.1", "cmdSecond", True)
    StyleButton cmdSecond, "Add &note", 184, 132, RGB(249, 234, 240)
    Set cmdCancel = Me.Controls.Add("Forms.CommandButton.1", "cmdCancel", True)
    StyleButton cmdCancel, "Cancel", 326, 114, RGB(255, 255, 255)
    cmdCancel.Cancel = True
    cmdFirst.Accelerator = "b": cmdSecond.Accelerator = "n": cmdCancel.Accelerator = "c"
End Sub
Private Sub StyleButton(ByVal button As MSForms.CommandButton, ByVal text As String, ByVal x As Single, ByVal width As Single, ByVal colour As Long)
    With button
        .Caption = Replace(text, "&", ""): .Left = x: .Top = 85: .width = width: .Height = 34
        .Font.name = "Tahoma": .Font.Size = 12
        .ForeColor = RGB(38, 50, 56): .BackColor = colour
    End With
End Sub
Private Sub cmdFirst_Click()
    Result = 1: Me.Hide
End Sub
Private Sub cmdSecond_Click()
    Result = 2: Me.Hide
End Sub
Private Sub cmdCancel_Click()
    Result = 0: Me.Hide
End Sub
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then Cancel = True: Result = 0: Me.Hide
End Sub

