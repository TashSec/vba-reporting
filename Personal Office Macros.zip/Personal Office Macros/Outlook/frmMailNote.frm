VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmMailNote 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmMailNote.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmMailNote"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public Result As Long
Public txtNote As MSForms.TextBox
Public txtFileName As MSForms.TextBox
Private WithEvents cmdAdd As MSForms.CommandButton
Attribute cmdAdd.VB_VarHelpID = -1
Private WithEvents cmdCancel As MSForms.CommandButton
Attribute cmdCancel.VB_VarHelpID = -1
Private Sub UserForm_Initialize()
    Me.Caption = "Add a note attachment": Me.width = 510: Me.Height = 440
    Me.Font.name = "Tahoma": Me.Font.Size = 12: Me.BackColor = RGB(252, 250, 252)
    AddLabel "lblNote", "Note text", 15
    Set txtNote = Me.Controls.Add("Forms.TextBox.1", "txtNote", True)
    With txtNote
        .Left = 18: .Top = 42: .width = 465: .Height = 230
        .Multiline = True: .EnterKeyBehavior = True: .ScrollBars = 2: .WordWrap = True
        .Font.name = "Tahoma": .Font.Size = 12: .ForeColor = RGB(38, 50, 56): .TabIndex = 0
    End With
    AddLabel "lblFile", "Attachment filename (.txt)", 286
    Set txtFileName = Me.Controls.Add("Forms.TextBox.1", "txtFileName", True)
    With txtFileName
        .Left = 18: .Top = 312: .width = 465: .Height = 28
        .Font.name = "Tahoma": .Font.Size = 12: .ForeColor = RGB(38, 50, 56): .TabIndex = 1
    End With
    Set cmdAdd = Me.Controls.Add("Forms.CommandButton.1", "cmdAdd", True)
    With cmdAdd
        .Left = 230: .Top = 358: .width = 132: .Height = 34
        .Caption = "Add note": .Accelerator = "a": .Default = True: .TabIndex = 2
        .Font.name = "Tahoma": .Font.Size = 12: .ForeColor = RGB(38, 50, 56): .BackColor = RGB(249, 234, 240)
    End With
    Set cmdCancel = Me.Controls.Add("Forms.CommandButton.1", "cmdCancel", True)
    With cmdCancel
        .Left = 372: .Top = 358: .width = 111: .Height = 34
        .Caption = "Cancel": .Accelerator = "c": .Cancel = True: .TabIndex = 3
        .Font.name = "Tahoma": .Font.Size = 12: .ForeColor = RGB(38, 50, 56): .BackColor = RGB(255, 255, 255)
    End With
End Sub
Private Sub AddLabel(ByVal name As String, ByVal text As String, ByVal y As Single)
    Dim label As MSForms.label
    Set label = Me.Controls.Add("Forms.Label.1", name, True)
    With label
        .Left = 18: .Top = y: .width = 460: .Height = 23
        .Caption = text: .Font.name = "Tahoma": .Font.Size = 12
        .ForeColor = RGB(38, 50, 56): .BackColor = Me.BackColor
    End With
End Sub
Private Sub cmdAdd_Click()
    If Len(Trim$(txtNote.text)) = 0 Then
        MsgBox "Type your note first.", vbInformation, "Add note"
        txtNote.SetFocus
        Exit Sub
    End If
    If Len(Trim$(txtFileName.text)) = 0 Then txtFileName.text = "Note.txt"
    Result = 1: Me.Hide
End Sub
Private Sub cmdCancel_Click()
    Result = 0: Me.Hide
End Sub
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then Cancel = True: Result = 0: Me.Hide
End Sub

