VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmMailCount 
   Caption         =   "UserForm1"
   ClientHeight    =   3015
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   4560
   OleObjectBlob   =   "frmMailCount.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmMailCount"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public lblCount As MSForms.label
Public lblInfo As MSForms.label
Private WithEvents cmdClose As MSForms.CommandButton
Attribute cmdClose.VB_VarHelpID = -1
Private Sub UserForm_Initialize()
    Me.Caption = "Selected message count": Me.width = 460: Me.Height = 235
    Me.Font.name = "Tahoma": Me.Font.Size = 12: Me.BackColor = RGB(252, 250, 252)
    Set lblCount = Me.Controls.Add("Forms.Label.1", "lblCount", True)
    With lblCount
        .Left = 18: .Top = 17: .width = 418: .Height = 34
        .Caption = "0 selected message(s)": .Font.name = "Tahoma": .Font.Size = 18: .Font.Bold = True
        .ForeColor = RGB(53, 94, 115): .BackColor = Me.BackColor
    End With
    Set lblInfo = Me.Controls.Add("Forms.Label.1", "lblInfo", True)
    With lblInfo
        .Left = 18: .Top = 64: .width = 418: .Height = 80: .WordWrap = True
        .Caption = "Count at the time you pressed the shortcut."
        .Font.name = "Tahoma": .Font.Size = 11
        .ForeColor = RGB(38, 50, 56): .BackColor = Me.BackColor
    End With
    Set cmdClose = Me.Controls.Add("Forms.CommandButton.1", "cmdClose", True)
    With cmdClose
        .Left = 324: .Top = 157: .width = 112: .Height = 32
        .Caption = "Close": .Accelerator = "c": .Cancel = True: .Default = True
        .Font.name = "Tahoma": .Font.Size = 12: .ForeColor = RGB(38, 50, 56): .BackColor = RGB(226, 240, 247)
    End With
End Sub
Private Sub cmdClose_Click()
    Me.Hide
End Sub
Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then Cancel = True: Me.Hide
End Sub

