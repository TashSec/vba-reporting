Attribute VB_Name = "modPersonalOutlookTools"
Option Explicit

#If VBA7 Then
Private Declare PtrSafe Function GetOpenFileNameW Lib "comdlg32.dll" (ByRef data As OPENFILENAMEW) As Long
Private Declare PtrSafe Function GetActiveWindow Lib "user32.dll" () As LongPtr
Private Declare PtrSafe Function CommDlgExtendedError Lib "comdlg32.dll" () As Long
#Else
Private Declare Function GetOpenFileNameW Lib "comdlg32.dll" (ByRef data As OPENFILENAMEW) As Long
Private Declare Function GetActiveWindow Lib "user32.dll" () As Long
Private Declare Function CommDlgExtendedError Lib "comdlg32.dll" () As Long
#End If

Private Type OPENFILENAMEW
    lStructSize As Long
#If VBA7 Then
    hwndOwner As LongPtr
    hInstance As LongPtr
    lpstrFilter As LongPtr
    lpstrCustomFilter As LongPtr
#Else
    hwndOwner As Long
    hInstance As Long
    lpstrFilter As Long
    lpstrCustomFilter As Long
#End If
    nMaxCustFilter As Long
    nFilterIndex As Long
#If VBA7 Then
    lpstrFile As LongPtr
#Else
    lpstrFile As Long
#End If
    nMaxFile As Long
#If VBA7 Then
    lpstrFileTitle As LongPtr
#Else
    lpstrFileTitle As Long
#End If
    nMaxFileTitle As Long
#If VBA7 Then
    lpstrInitialDir As LongPtr
    lpstrTitle As LongPtr
#Else
    lpstrInitialDir As Long
    lpstrTitle As Long
#End If
    flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
#If VBA7 Then
    lpstrDefExt As LongPtr
    lCustData As LongPtr
    lpfnHook As LongPtr
    lpTemplateName As LongPtr
    pvReserved As LongPtr
#Else
    lpstrDefExt As Long
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As Long
    pvReserved As Long
#End If
    dwReserved As Long
    flagsEx As Long
End Type

Private Const CID As String = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"
Private Const LOCATION As String = "http://schemas.microsoft.com/mapi/proptag/0x3713001F"
Private Const MIME As String = "http://schemas.microsoft.com/mapi/proptag/0x370E001F"
Private Const HIDDEN As String = "http://schemas.microsoft.com/mapi/proptag/0x7FFE000B"

Public Function PT_OutlookApp() As Outlook.Application
    Dim host As Object
    Set host = Application
    If InStr(1, host.Name, "Outlook", vbTextCompare) > 0 Then
        Set PT_OutlookApp = host
    Else
        Set PT_OutlookApp = GetObject(, "Outlook.Application")
    End If
End Function

Public Function PT_SelectedMessages(Optional ByRef otherItems As Long = 0, Optional ByRef conversations As Long = 0) As Collection
    Dim result As New Collection, app As Outlook.Application, win As Object, item As Object
    Dim selection As Outlook.selection, headers As Outlook.selection
    Set app = PT_OutlookApp(): Set win = app.ActiveWindow
    If TypeOf win Is Outlook.Inspector Then
        Set item = win.CurrentItem
        If TypeOf item Is Outlook.MailItem Then result.Add item Else otherItems = 1
    ElseIf TypeOf win Is Outlook.Explorer Then
        Set selection = win.selection
        For Each item In selection
            If TypeOf item Is Outlook.MailItem Then
                result.Add item
            Else
                otherItems = otherItems + 1
            End If
        Next item
        On Error Resume Next
        Set headers = selection.GetSelection(olConversationHeaders)
        If Not headers Is Nothing Then conversations = headers.Count
        On Error GoTo 0
    End If
    Set PT_SelectedMessages = result
End Function

Public Sub PT_CountSelectedMessages()
    On Error GoTo Failed
    Dim mails As Collection, other As Long, conversations As Long, note As String
    Set mails = PT_SelectedMessages(other, conversations)
    note = "Count at the time you pressed the shortcut."
    If other > 0 Then note = note & vbCrLf & CStr(other) & " non-mail row(s) excluded."
    If conversations > 0 Then note = note & vbCrLf & "Expand conversation groups and select individual messages."
    frmMailCount.lblCount.Caption = Format$(mails.Count, "#,##0") & " selected message(s)"
    frmMailCount.lblInfo.Caption = note
    If Not frmMailCount.Visible Then frmMailCount.Show vbModeless
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Outlook personal tools"
End Sub

Public Sub PT_AddAttachmentOrNote()
    On Error GoTo Failed
    Dim mails As Collection, choice As Long, files As Collection, noteFile As String, temp As String
    Dim item As Outlook.MailItem, successful As Long, failures As String, description As String
    Set mails = PT_SelectedMessages()
    If mails.Count = 0 Then Err.Raise vbObjectError + 801, , "Select individual email messages first."
    With frmMailChoice
        .Caption = "Add attachment or note"
        .lblInfo.Caption = "Add to " & CStr(mails.Count) & " selected email message(s)."
        .cmdFirst.Caption = "Browse files...": .cmdSecond.Caption = "Add note"
        .cmdFirst.Accelerator = "b": .cmdSecond.Accelerator = "n"
        .Result = 0: .Show vbModal: choice = .Result
    End With
    If choice = 0 Then Exit Sub
    If choice = 1 Then
        Set files = PT_BrowseFiles()
        If files.Count = 0 Then Exit Sub
    Else
        frmMailNote.Result = 0
        frmMailNote.txtNote.Text = ""
        frmMailNote.txtFileName.Text = "Note - " & Format$(Now, "yyyy-mm-dd hh-nn") & ".txt"
        frmMailNote.Show vbModal
        If frmMailNote.Result = 0 Then Exit Sub
        temp = PT_CreateTempFolder()
        noteFile = temp & "\" & PT_SafeFileName(frmMailNote.txtFileName.Text)
        If LCase$(Right$(noteFile, 4)) <> ".txt" Then noteFile = noteFile & ".txt"
        PT_WriteUTF8 noteFile, frmMailNote.txtNote.Text
        Set files = New Collection: files.Add noteFile
    End If
    For Each item In mails
        On Error Resume Next
        Err.Clear
        PT_AddFilesToOne item, files
        description = Err.Description
        If Err.Number = 0 Then
            successful = successful + 1
        Else
            failures = failures & vbCrLf & Left$(item.Subject, 70) & ": " & description
        End If
        On Error GoTo Failed
    Next item
    If Len(temp) Then PT_CleanTemp temp
    MsgBox CStr(successful) & " message(s) updated." & IIf(Len(failures), vbCrLf & "Not updated:" & failures, ""), _
        IIf(Len(failures), vbExclamation, vbInformation), "Attachments and notes"
    Exit Sub
Failed:
    description = Err.Description
    If Len(temp) Then PT_CleanTemp temp
    MsgBox description, vbExclamation, "Outlook personal tools"
End Sub

Public Sub PT_AddFilesToOne(ByVal item As Outlook.MailItem, ByVal files As Collection, Optional ByVal backupBase As String = "")
    Dim fso As Object, file As Variant, before As Long, backup As String, message As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    For Each file In files
        If Not fso.FileExists(CStr(file)) Then Err.Raise vbObjectError + 802, , "Attachment file not found: " & CStr(file)
    Next file
    If Len(item.EntryID) > 0 Then
        If Not item.Saved Then Err.Raise vbObjectError + 803, , "Save or close your existing unsaved edits first."
        backup = PT_BackupMessage(item, backupBase)
    End If
    before = item.Attachments.Count
    On Error GoTo Failed
    For Each file In files
        item.Attachments.Add CStr(file), olByValue
    Next file
    item.Save
    Exit Sub
Failed:
    message = Err.Description
    On Error Resume Next
    Do While item.Attachments.Count > before
        item.Attachments.Remove item.Attachments.Count
    Loop
    On Error GoTo 0
    If Len(backup) Then message = message & vbCrLf & "Original message copy: " & backup
    Err.Raise vbObjectError + 804, , message
End Sub

Public Sub PT_ForwardOrReplyAllWithAttachments()
    On Error GoTo Failed
    Dim mails As Collection, action As Long, source As Outlook.MailItem, draft As Outlook.MailItem
    Dim successes As Long, errors As String, message As String
    Set mails = PT_SelectedMessages()
    If mails.Count = 0 Then Err.Raise vbObjectError + 805, , "Select individual email messages first."
    With frmMailChoice
        .Caption = "Forward or reply all"
        .lblInfo.Caption = "Create one draft per selected message (" & CStr(mails.Count) & ")."
        .cmdFirst.Caption = "Forward": .cmdSecond.Caption = "Reply all"
        .cmdFirst.Accelerator = "f": .cmdSecond.Accelerator = "a"
        .Result = 0: .Show vbModal: action = .Result
    End With
    If action = 0 Then Exit Sub
    For Each source In mails
        Set draft = Nothing
        On Error Resume Next
        Err.Clear
        Set draft = PT_CreateResponse(source, action)
        message = Err.Description
        If Err.Number = 0 Then
            draft.Display
            If Err.Number = 0 Then successes = successes + 1 Else message = Err.Description
        End If
        If Len(message) Then errors = errors & vbCrLf & Left$(source.Subject, 70) & ": " & message
        On Error GoTo Failed
    Next source
    If Len(errors) Then MsgBox CStr(successes) & " draft(s) opened." & vbCrLf & "Not completed:" & errors, vbExclamation, "Draft results"
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Outlook personal tools"
End Sub

Public Function PT_CreateResponse(ByVal source As Outlook.MailItem, ByVal action As Long) As Outlook.MailItem
    Dim draft As Outlook.MailItem, message As String, stepName As String
    On Error GoTo Failed
    If action = 1 Then
        stepName = "Create forward"
        Set draft = source.Forward
    ElseIf action = 2 Then
        stepName = "Create reply all"
        Set draft = source.ReplyAll
    Else
        Err.Raise vbObjectError + 806, , "Unknown response action."
    End If
    stepName = "Copy original attachments"
    PT_CopyOriginalAttachments source, draft
    Set PT_CreateResponse = draft
    Exit Function
Failed:
    message = Err.Description
    On Error Resume Next
    If Not draft Is Nothing Then draft.Close olDiscard
    On Error GoTo 0
    Err.Raise vbObjectError + 807, , stepName & " failed; incomplete draft discarded. " & message
End Function

Public Sub PT_CopyOriginalAttachments(ByVal source As Outlook.MailItem, ByVal draft As Outlook.MailItem)
    Dim temp As String, i As Long, a As Outlook.Attachment, added As Outlook.Attachment
    Dim folder As String, file As String, fso As Object, property As Variant, value As Variant, message As String
    Dim matched As Object, match As Long, stepName As String
    On Error GoTo Failed
    If source.Attachments.Count > 0 Then
        temp = PT_CreateTempFolder(): Set fso = CreateObject("Scripting.FileSystemObject")
        Set matched = CreateObject("Scripting.Dictionary")
        For i = 1 To source.Attachments.Count
            Set a = source.Attachments(i)
            stepName = "Keep attachment " & CStr(i) & " (" & a.FileName & ")"
            match = PT_FindAttachmentMatch(draft, a, matched)
            If match = 0 Then
                folder = temp & "\" & Format$(i, "0000"): fso.CreateFolder folder
                file = folder & "\" & PT_SafeFileName(a.FileName)
                a.SaveAsFile file
                Set added = draft.Attachments.Add(file, olByValue)
                For Each property In Array(CID, LOCATION, MIME, HIDDEN)
                    On Error Resume Next
                    Err.Clear
                    value = a.PropertyAccessor.GetProperty(CStr(property))
                    If Err.Number = 0 Then added.PropertyAccessor.SetProperty CStr(property), value
                    On Error GoTo Failed
                Next property
                matched(CStr(draft.Attachments.Count)) = True
            Else
                matched(CStr(match)) = True
            End If
        Next i
    End If
    If Len(temp) Then PT_CleanTemp temp
    Exit Sub
Failed:
    message = Err.Description
    If Len(temp) Then PT_CleanTemp temp
    Err.Raise vbObjectError + 807, , stepName & " failed; incomplete draft discarded. " & message
End Sub

Private Function PT_FindAttachmentMatch(ByVal draft As Outlook.MailItem, ByVal source As Outlook.Attachment, ByVal matched As Object) As Long
    Dim i As Long, candidate As Outlook.Attachment, id As String
    id = CStr(PT_AttachmentProperty(source, CID))
    For i = 1 To draft.Attachments.Count
        If Not matched.Exists(CStr(i)) Then
            Set candidate = draft.Attachments(i)
            If Len(id) > 0 Then
                If CStr(PT_AttachmentProperty(candidate, CID)) = id Then
                    PT_FindAttachmentMatch = i: Exit Function
                End If
            ElseIf StrComp(candidate.FileName, source.FileName, vbTextCompare) = 0 And candidate.Type = source.Type Then
                PT_FindAttachmentMatch = i: Exit Function
            End If
        End If
    Next i
End Function

Private Function PT_AttachmentProperty(ByVal attachment As Outlook.Attachment, ByVal property As String) As Variant
    On Error Resume Next
    PT_AttachmentProperty = attachment.PropertyAccessor.GetProperty(property)
    If Err.Number <> 0 Then PT_AttachmentProperty = ""
    On Error GoTo 0
End Function

Private Function PT_HasContentID(ByVal item As Outlook.MailItem, ByVal id As String) As Boolean
    Dim a As Outlook.Attachment
    If Len(id) = 0 Then Exit Function
    For Each a In item.Attachments
        If CStr(PT_AttachmentProperty(a, CID)) = id Then PT_HasContentID = True: Exit Function
    Next a
End Function

Public Function PT_BrowseFiles() As Collection
    Dim chosen As New Collection, data As OPENFILENAMEW, buffer As String, filter As String, title As String
    Dim result As Long, parts As Variant, i As Long, errorCode As Long
    buffer = String$(65536, vbNullChar)
    filter = "All files (*.*)" & vbNullChar & "*.*" & vbNullChar & vbNullChar
    title = "Choose attachment files"
    data.lStructSize = LenB(data): data.hwndOwner = GetActiveWindow()
    data.lpstrFilter = StrPtr(filter): data.nFilterIndex = 1
    data.lpstrFile = StrPtr(buffer): data.nMaxFile = Len(buffer)
    data.lpstrTitle = StrPtr(title)
    data.flags = &H80000 Or &H200 Or &H1000 Or &H800 Or &H8
    result = GetOpenFileNameW(data)
    If result = 0 Then
        errorCode = CommDlgExtendedError()
        If errorCode <> 0 Then Err.Raise vbObjectError + 808, , "File picker could not open (" & CStr(errorCode) & ")."
    Else
        parts = Split(buffer, vbNullChar)
        If Len(parts(1)) = 0 Then
            chosen.Add parts(0)
        Else
            i = 1
            Do While Len(parts(i)) > 0
                chosen.Add parts(0) & "\" & parts(i)
                i = i + 1
            Loop
        End If
    End If
    Set PT_BrowseFiles = chosen
End Function

Public Function PT_FilePickerStructureBytes() As Long
    Dim data As OPENFILENAMEW
    PT_FilePickerStructureBytes = LenB(data)
End Function

Public Function PT_SafeFileName(ByVal name As String) As String
    Dim bad As Variant, stem As String
    name = Trim$(name)
    For Each bad In Array("\", "/", ":", "*", "?", """", "<", ">", "|")
        name = Replace(name, CStr(bad), "_")
    Next bad
    Dim i As Long
    For i = 0 To 31
        name = Replace(name, Chr$(i), "_")
    Next i
    Do While Len(name) > 0
        If Right$(name, 1) <> "." And Right$(name, 1) <> " " Then Exit Do
        name = Left$(name, Len(name) - 1)
    Loop
    If Len(name) = 0 Then name = "Attachment"
    name = Left$(name, 140)
    stem = UCase$(Split(name, ".")(0))
    If stem = "CON" Or stem = "PRN" Or stem = "AUX" Or stem = "NUL" Or _
        stem Like "COM[1-9]" Or stem Like "LPT[1-9]" Then name = "File-" & name
    PT_SafeFileName = name
End Function

Public Sub PT_WriteUTF8(ByVal path As String, ByVal text As String)
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    stream.WriteText text
    stream.SaveToFile path, 2
    stream.Close
End Sub

Public Function PT_CreateTempFolder() As String
    Dim fso As Object, folder As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    Do
        folder = fso.GetSpecialFolder(2).path & "\PersonalOfficeMacros-" & fso.GetTempName
    Loop While fso.FileExists(folder) Or fso.FolderExists(folder)
    fso.CreateFolder folder
    PT_CreateTempFolder = folder
End Function

Public Sub PT_CleanTemp(ByVal folder As String)
    On Error Resume Next
    Dim fso As Object, prefix As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    prefix = fso.GetSpecialFolder(2).path & "\PersonalOfficeMacros-"
    If StrComp(Left$(folder, Len(prefix)), prefix, vbTextCompare) = 0 Then
        If InStr(Mid$(folder, Len(prefix) + 1), "\") = 0 Then fso.DeleteFolder folder, True
    End If
    On Error GoTo 0
End Sub

Public Function PT_BackupMessage(ByVal item As Outlook.MailItem, Optional ByVal base As String = "") As String
    Dim fso As Object, folder As String, path As String, stem As String, i As Long
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Len(base) = 0 Then base = CreateObject("WScript.Shell").SpecialFolders("MyDocuments") & "\Personal Office Macro Backups"
    If Not fso.FolderExists(base) Then fso.CreateFolder base
    folder = base & "\Outlook"
    If Not fso.FolderExists(folder) Then fso.CreateFolder folder
    stem = Left$(PT_SafeFileName(item.Subject), 70) & " - before attachments - " & Format$(Now, "yyyymmdd-hhnnss")
    path = folder & "\" & stem & ".msg"
    Do While fso.FileExists(path)
        i = i + 1: path = folder & "\" & stem & "-" & CStr(i) & ".msg"
    Loop
    item.SaveAs path, olMSGUnicode
    PT_BackupMessage = path
End Function
