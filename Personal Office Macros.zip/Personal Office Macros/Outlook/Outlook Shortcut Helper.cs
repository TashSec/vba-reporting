using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

internal static class NativeKeys {
    internal delegate IntPtr HookProc(int code, IntPtr message, IntPtr data);
    [DllImport("user32.dll",SetLastError=true)] internal static extern IntPtr SetWindowsHookEx(int kind,HookProc callback,IntPtr module,uint thread);
    [DllImport("user32.dll")] internal static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")] internal static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr message,IntPtr data);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] internal static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] internal static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] internal static extern int GetClassName(IntPtr window,StringBuilder value,int max);
    [DllImport("user32.dll",SetLastError=true)] internal static extern uint SendInput(uint count,Input[] input,int bytes);
    [StructLayout(LayoutKind.Sequential)] internal struct Keyboard {internal ushort key,scan;internal uint flags,time;internal IntPtr extra;}
    [StructLayout(LayoutKind.Sequential)] internal struct Mouse {internal int x,y;internal uint data,flags,time;internal IntPtr extra;}
    [StructLayout(LayoutKind.Explicit)] internal struct Union {[FieldOffset(0)]internal Mouse mouse;[FieldOffset(0)]internal Keyboard keyboard;}
    [StructLayout(LayoutKind.Sequential)] internal struct Input {internal uint type;internal Union data;}
    [StructLayout(LayoutKind.Sequential)] internal struct HookData {internal uint key,scan,flags,time;internal IntPtr extra;}
    internal static bool Down(int key){return (GetAsyncKeyState(key)&0x8000)!=0;}
    internal static int Route(string process,string windowClass,bool ctrl,bool shift,bool alt,int key){
        if(!ctrl||!shift||alt||!String.Equals(process,"OUTLOOK",StringComparison.OrdinalIgnoreCase)||windowClass!="rctrl_renwnd32")return 0;
        if(key==81)return 1;if(key==87)return 2;if(key==69)return 3;return 0;
    }
    internal static int RouteWindow(IntPtr window,int key){
        if(window==IntPtr.Zero)return 0;
        uint id;GetWindowThreadProcessId(window,out id);
        var text=new StringBuilder(100);GetClassName(window,text,100);
        if(text.ToString()!="rctrl_renwnd32")return 0;
        try{return Route(Process.GetProcessById((int)id).ProcessName,text.ToString(),Down(17),Down(16),Down(18),key);}catch{return 0;}
    }
    internal static bool IsOutlookWindow(IntPtr window){
        uint id;GetWindowThreadProcessId(window,out id);var text=new StringBuilder(100);GetClassName(window,text,100);
        try{return text.ToString()=="rctrl_renwnd32"&&Process.GetProcessById((int)id).ProcessName.Equals("OUTLOOK",StringComparison.OrdinalIgnoreCase);}catch{return false;}
    }
    internal static Input Key(int key,bool release){var v=new Input();v.type=1;v.data.keyboard.key=(ushort)key;v.data.keyboard.flags=release?2u:0u;return v;}
    internal static bool AltNumber(int number){
        var values=new[]{Key(18,false),Key(48+number,false),Key(48+number,true),Key(18,true)};
        return SendInput((uint)values.Length,values,Marshal.SizeOf(typeof(Input)))==values.Length;
    }
}

internal sealed class HelperForm:Form {
    private readonly Label status=new Label();
    private readonly CheckBox ready=new CheckBox();
    private readonly Button start=new Button(),pause=new Button();
    private readonly Timer pending=new Timer();
    private readonly NotifyIcon tray=new NotifyIcon();
    private NativeKeys.HookProc callback;
    private IntPtr hook=IntPtr.Zero,owner=IntPtr.Zero;
    private int action,tries;
    private bool active;
    internal HelperForm(){
        Text="Outlook shortcut helper";ClientSize=new Size(570,435);Font=new Font("Tahoma",11);BackColor=Color.FromArgb(252,250,252);ForeColor=Color.FromArgb(38,50,56);
        FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;StartPosition=FormStartPosition.CenterScreen;
        AddLabel("Outlook Classic shortcuts",20,18,530,35,17,Color.FromArgb(120,77,101),true);
        AddLabel("Set these macros as the first three Quick Access Toolbar buttons:",20,66,530,43,11,ForeColor,false);
        AddLabel("Alt+1 / Ctrl+Shift+Q     Count selected messages\nAlt+2 / Ctrl+Shift+W     Add attachment or note\nAlt+3 / Ctrl+Shift+E      Forward or reply all",20,118,530,87,11,Color.FromArgb(53,94,115),false);
        ready.SetBounds(20,215,530,48);ready.Text="I checked that Alt+1, Alt+2 and Alt+3 run these macros in the Outlook windows I use.";
        ready.CheckedChanged+=(s,e)=>{start.Enabled=ready.Checked&&!active;if(!ready.Checked)Pause();};Controls.Add(ready);
        start.SetBounds(20,276,175,40);start.Text="Start shortcuts";start.BackColor=Color.FromArgb(226,240,247);start.Enabled=false;start.Click+=(s,e)=>StartKeys();Controls.Add(start);
        pause.SetBounds(210,276,135,40);pause.Text="Pause";pause.Enabled=false;pause.BackColor=Color.FromArgb(249,234,240);pause.Click+=(s,e)=>Pause();Controls.Add(pause);
        var exit=new Button{Text="Exit",BackColor=Color.White};exit.SetBounds(360,276,120,40);exit.Click+=(s,e)=>Close();Controls.Add(exit);
        status.SetBounds(20,335,530,72);status.Text="Paused. Keep this helper open only when you want these shortcuts.";status.ForeColor=Color.FromArgb(53,94,115);Controls.Add(status);
        pending.Interval=20;pending.Tick+=(s,e)=>Dispatch();
        var menu=new ContextMenuStrip();menu.Items.Add("Open helper",null,(s,e)=>{Show();WindowState=FormWindowState.Normal;Activate();});menu.Items.Add("Pause shortcuts",null,(s,e)=>Pause());menu.Items.Add("Exit",null,(s,e)=>Close());
        tray.Icon=SystemIcons.Application;tray.Text="Outlook shortcut helper (paused)";tray.ContextMenuStrip=menu;tray.DoubleClick+=(s,e)=>{Show();WindowState=FormWindowState.Normal;Activate();};tray.Visible=true;
        Resize+=(s,e)=>{if(WindowState==FormWindowState.Minimized)Hide();};FormClosed+=(s,e)=>{Pause();tray.Visible=false;tray.Dispose();};
    }
    private void AddLabel(string text,int x,int y,int w,int h,int size,Color colour,bool bold){var l=new Label{Text=text,Font=new Font("Tahoma",size,bold?FontStyle.Bold:FontStyle.Regular),ForeColor=colour};l.SetBounds(x,y,w,h);Controls.Add(l);}
    private void StartKeys(){
        if(!ready.Checked)return;
        callback=Hook;
        hook=NativeKeys.SetWindowsHookEx(13,callback,NativeKeys.GetModuleHandle(null),0);
        if(hook==IntPtr.Zero){status.Text="Windows did not allow the helper to start. Use the Alt+1 / Alt+2 / Alt+3 toolbar keys instead.";return;}
        active=true;start.Enabled=false;pause.Enabled=true;tray.Text="Outlook shortcut helper (active)";status.Text="Active for Outlook Classic message windows only. Tap and release the shortcut. Other apps keep their normal keys.";
    }
    private void Pause(){
        active=false;pending.Stop();action=0;
        if(hook!=IntPtr.Zero){NativeKeys.UnhookWindowsHookEx(hook);hook=IntPtr.Zero;}
        start.Enabled=ready.Checked;pause.Enabled=false;status.Text="Paused. Outlook's original shortcuts are restored.";tray.Text="Outlook shortcut helper (paused)";
    }
    private IntPtr Hook(int code,IntPtr message,IntPtr data){
        if(code>=0&&active&&(message.ToInt32()==0x100||message.ToInt32()==0x104)){
            var value=(NativeKeys.HookData)Marshal.PtrToStructure(data,typeof(NativeKeys.HookData));
            if((value.flags&0x10)==0){
                IntPtr window=NativeKeys.GetForegroundWindow();int route=NativeKeys.RouteWindow(window,(int)value.key);
                if(route!=0){if(action==0){owner=window;action=route;tries=0;pending.Start();}return new IntPtr(1);}
            }
        }
        return NativeKeys.CallNextHookEx(hook,code,message,data);
    }
    private void Dispatch(){
        if(++tries>150){pending.Stop();action=0;return;}
        if(NativeKeys.Down(17)||NativeKeys.Down(16)||NativeKeys.Down(18))return;
        pending.Stop();int selected=action;action=0;
        if(NativeKeys.GetForegroundWindow()!=owner||!NativeKeys.IsOutlookWindow(owner))return;
        if(!NativeKeys.AltNumber(selected))status.Text="Windows blocked the toolbar key. Use the Outlook toolbar button; do not run the helper as administrator.";
    }
    internal static int SelfTest(string folder){
        Directory.CreateDirectory(folder);int checks=0;
        Action<bool> test=value=>{checks++;if(!value)throw new Exception("Helper test "+checks+" failed");};
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,true,false,81)==1);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,true,false,87)==2);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,true,false,69)==3);
        test(NativeKeys.Route("EXCEL","rctrl_renwnd32",true,true,false,81)==0);
        test(NativeKeys.Route("OUTLOOK","#32770",true,true,false,81)==0);
        test(NativeKeys.Route("OUTLOOK","ThunderDFrame",true,true,false,81)==0);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",false,true,false,81)==0);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,false,false,81)==0);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,true,true,81)==0);
        test(NativeKeys.Route("OUTLOOK","rctrl_renwnd32",true,true,false,82)==0);
        test(Marshal.SizeOf(typeof(NativeKeys.Input))==(IntPtr.Size==8?40:28));
        using(var form=new HelperForm()){
            form.StartPosition=FormStartPosition.Manual;form.Location=new Point(-2000,-2000);form.Show();Application.DoEvents();form.PerformLayout();test(!form.start.Enabled&&!form.active);
            using(var image=new Bitmap(form.Width,form.Height)){form.DrawToBitmap(image,new Rectangle(0,0,image.Width,image.Height));image.Save(Path.Combine(folder,"helper-preview.png"));}
            form.Hide();
            NativeKeys.HookProc pass=(c,m,d)=>NativeKeys.CallNextHookEx(IntPtr.Zero,c,m,d);
            var handle=NativeKeys.SetWindowsHookEx(13,pass,NativeKeys.GetModuleHandle(null),0);test(handle!=IntPtr.Zero);test(NativeKeys.UnhookWindowsHookEx(handle));GC.KeepAlive(pass);
        }
        File.WriteAllText(Path.Combine(folder,"helper-validation.json"),"{\"checks\":"+checks+",\"passed\":true,\"inputInjected\":false,\"liveOfficeConfigured\":false}");
        return 0;
    }
}

internal static class Program {
    [STAThread] private static int Main(string[] args){
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        if(args.Length==2&&args[0]=="--self-test")return HelperForm.SelfTest(args[1]);
        bool first;using(var mutex=new System.Threading.Mutex(true,"Local\\PersonalOfficeOutlookShortcutHelper",out first)){
            if(!first){MessageBox.Show("The helper is already running. Open it from the system tray.","Outlook shortcut helper");return 0;}
            Application.Run(new HelperForm());return 0;
        }
    }
}
