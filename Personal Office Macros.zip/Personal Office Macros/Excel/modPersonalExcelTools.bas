Attribute VB_Name = "modPersonalExcelTools"
Option Explicit

Public PN_Events As cPersonalExcelEvents
Private Const ROUND_PREFIX As String = "_PN_Hundreds_"
Private Const TWO_DP As String = "#,##0.00;[Red]-#,##0.00;""-"";@"
Private Const ZERO_DP As String = "#,##0;[Red]-#,##0;""-"";@"
Private Const THOUSANDS As String = "#,##0,"",000"";[Red]-#,##0,"",000"";""-"";@"
Private refreshing As Boolean

Public Sub PN_Start()
    Dim names As Variant, letters As Variant, i As Long, macroPath As String
    letters = Array("q", "w", "e", "r", "t", "y")
    names = Array("PN_Format2DP", "PN_Format0DP", "PN_DisplayHundreds", "PN_DisplayThousands", "PN_DeleteBlankRows", "PN_SelectColumnsToLastRow")
    macroPath = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!"
    For i = 0 To 5
        Application.OnKey "^+" & letters(i), macroPath & names(i)
    Next i
    Set PN_Events = New cPersonalExcelEvents
    Set PN_Events.App = Application
    Dim book As Workbook
    For Each book In Application.Workbooks
        PN_RefreshWorkbook book
    Next book
End Sub

Public Sub PN_Stop()
    Dim key As Variant
    For Each key In Array("q", "w", "e", "r", "t", "y")
        Application.OnKey "^+" & CStr(key)
    Next key
    Set PN_Events = Nothing
    Application.StatusBar = False
End Sub

Private Function SelectedCells() As Range
    If TypeName(Selection) <> "Range" Then Err.Raise vbObjectError + 701, , "Select worksheet cells first."
    Set SelectedCells = Selection
    If SelectedCells.Parent.ProtectContents Then Err.Raise vbObjectError + 702, , "This worksheet is protected."
End Function

Public Sub PN_Format2DP()
    SetStandardFormat TWO_DP, "0.005"
End Sub

Public Sub PN_Format0DP()
    SetStandardFormat ZERO_DP, "0.5"
End Sub

Public Sub PN_DisplayThousands()
    SetStandardFormat THOUSANDS, "500"
End Sub

Public Sub PN_ResetNumberFormat()
    SetStandardFormat "General"
End Sub

Private Sub SetStandardFormat(ByVal code As String, Optional ByVal threshold As String = "")
    On Error GoTo Failed
    Dim target As Range
    Set target = SelectedCells()
    RemoveHundredsTracking target
    RemoveDisplayRules target
    target.NumberFormat = code
    If Len(threshold) Then AddDisplayRules target, threshold, True
    Application.StatusBar = "Number display updated; values and formulas kept."
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Excel personal tools"
End Sub

Public Sub PN_DisplayHundreds()
    On Error GoTo Failed
    Dim target As Range, area As Range, nm As Name, number As Long
    Set target = SelectedCells()
    RemoveHundredsTracking target
    RemoveDisplayRules target
    AddDisplayRules target, "50", False
    number = 1
    For Each area In target.Areas
        Do While NameExists(target.Parent.Parent, ROUND_PREFIX & Format$(number, "000000"))
            number = number + 1
        Loop
        Set nm = target.Parent.Parent.Names.Add(Name:=ROUND_PREFIX & Format$(number, "000000"), _
            RefersTo:="='" & Replace(target.Parent.Name, "'", "''") & "'!" & area.Address, Visible:=False)
    Next area
    PN_RefreshWorkbook target.Parent.Parent
    Application.StatusBar = "Nearest 100 displayed; values and formulas kept."
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Excel personal tools"
End Sub

Private Function DisplayRuleFormula(ByVal cell As Range, ByVal threshold As String, ByVal negative As Boolean) As String
    Dim address As String, test As String, marker As String
    address = cell.Address(False, False)
    If negative Then
        test = "ABS(" & address & ")>=" & threshold
        marker = "PN_NegativeDisplay"
        DisplayRuleFormula = "=IFERROR(AND(ISNUMBER(" & address & ")," & address & "<0," & test & ",N(""" & marker & """)=0),FALSE)"
    Else
        test = "ABS(" & address & ")<" & threshold
        marker = "PN_ZeroDisplay"
        DisplayRuleFormula = "=IFERROR(AND(ISNUMBER(" & address & ")," & test & ",N(""" & marker & """)=0),FALSE)"
    End If
End Function

Private Sub AddDisplayRules(ByVal target As Range, ByVal threshold As String, ByVal zeros As Boolean)
    Dim area As Range
    For Each area In target.Areas
        If zeros Then AddOneDisplayRule area, threshold, False
        AddOneDisplayRule area, threshold, True
    Next area
End Sub

Private Sub AddOneDisplayRule(ByVal target As Range, ByVal threshold As String, ByVal negative As Boolean)
    Dim rule As FormatCondition
    Set rule = target.FormatConditions.Add(Type:=xlExpression, Formula1:=DisplayRuleFormula(target.Cells(1, 1), threshold, negative))
    If negative Then rule.Font.Color = RGB(192, 0, 0) Else rule.NumberFormat = """-"";""-"";""-"";@"
    rule.StopIfTrue = False
    rule.SetFirstPriority
End Sub

Private Sub RemoveDisplayRules(ByVal target As Range)
    Dim area As Range
    For Each area In target.Areas
        RemoveAreaDisplayRules area
    Next area
End Sub

Private Sub RemoveAreaDisplayRules(ByVal target As Range)
    Dim rules As FormatConditions, rule As FormatCondition, i As Long, formula As String, own As Boolean
    Dim keep As Collection, area As Range, part As Range, remains As Range, threshold As String
    Dim negative As Boolean, start As Long, finish As Long
    Dim changed As Boolean
    Do
    changed = False
    Set rules = target.FormatConditions
    For i = 1 To rules.Count
        If rules(i).Type = xlExpression Then
            Set rule = rules(i)
            formula = rule.Formula1
            own = InStr(formula, "N(""PN_ZeroDisplay"")") > 0 Or InStr(formula, "N(""PN_NegativeDisplay"")") > 0
            If own Then
                If Not Application.Intersect(rule.AppliesTo, target) Is Nothing Then
                    Set keep = New Collection
                    For Each area In rule.AppliesTo.Areas
                        keep.Add area
                    Next area
                    For Each area In target.Areas
                        Set keep = SubtractRectangle(keep, area)
                    Next area
                    Set remains = Nothing
                    For Each part In keep
                        If remains Is Nothing Then Set remains = part Else Set remains = Application.Union(remains, part)
                    Next part
                    If Not remains Is Nothing Then
                        negative = InStr(formula, "PN_NegativeDisplay") > 0
                        start = InStr(formula, "ABS(")
                        start = InStr(start, formula, ")") + IIf(negative, 3, 2)
                        finish = InStr(start, formula, ",")
                        threshold = Mid$(formula, start, finish - start)
                    End If
                    rule.Delete
                    If Not remains Is Nothing Then
                        For Each part In remains.Areas
                            AddOneDisplayRule part, threshold, negative
                        Next part
                    End If
                    changed = True
                    Exit For
                End If
            End If
        End If
    Next i
    Loop While changed
End Sub

Private Function NameExists(ByVal book As Workbook, ByVal key As String) As Boolean
    Dim nm As Name
    On Error Resume Next
    Set nm = book.Names(key)
    NameExists = Not nm Is Nothing
    On Error GoTo 0
End Function

Private Function IsHundredsName(ByVal nm As Name) As Boolean
    IsHundredsName = (Left$(nm.Name, Len(ROUND_PREFIX)) = ROUND_PREFIX)
End Function

Private Sub RemoveHundredsTracking(ByVal target As Range)
    Dim book As Workbook, i As Long, oldRange As Range, cut As Range, part As Range
    Dim keep As Collection, area As Range, newRange As Range, nm As Name, ref As String
    Set book = target.Parent.Parent
    For i = book.Names.Count To 1 Step -1
        Set nm = book.Names(i)
        If IsHundredsName(nm) Then
            Set oldRange = Nothing
            On Error Resume Next
            Set oldRange = nm.RefersToRange
            On Error GoTo 0
            If oldRange Is Nothing Then
                nm.Delete
            ElseIf oldRange.Parent Is target.Parent Then
                Set cut = Application.Intersect(oldRange, target)
                If Not cut Is Nothing Then
                    Set keep = New Collection
                    For Each area In oldRange.Areas
                        keep.Add area
                    Next area
                    For Each area In target.Areas
                        Set keep = SubtractRectangle(keep, area)
                    Next area
                    Set newRange = Nothing
                    For Each part In keep
                        If newRange Is Nothing Then
                            Set newRange = part
                        Else
                            Set newRange = Application.Union(newRange, part)
                        End If
                    Next part
                    If newRange Is Nothing Then
                        nm.Delete
                    Else
                        ref = RangeReference(newRange)
                        nm.RefersTo = ref
                    End If
                End If
            End If
        End If
    Next i
End Sub

Private Function RangeReference(ByVal cells As Range) As String
    Dim area As Range, text As String
    For Each area In cells.Areas
        If Len(text) Then text = text & ","
        text = text & "'" & Replace(area.Parent.Name, "'", "''") & "'!" & area.Address
    Next area
    RangeReference = "=" & text
End Function

Private Function SubtractRectangle(ByVal source As Collection, ByVal cut As Range) As Collection
    Dim result As New Collection, r As Range, overlap As Range, sh As Worksheet
    Dim topRow As Long, bottomRow As Long, leftCol As Long, rightCol As Long
    Dim ot As Long, ob As Long, ol As Long, oright As Long
    For Each r In source
        Set overlap = Application.Intersect(r, cut)
        If overlap Is Nothing Then
            result.Add r
        Else
            Set sh = r.Parent
            topRow = r.Row: bottomRow = r.Row + r.Rows.Count - 1
            leftCol = r.Column: rightCol = r.Column + r.Columns.Count - 1
            ot = overlap.Row: ob = overlap.Row + overlap.Rows.Count - 1
            ol = overlap.Column: oright = overlap.Column + overlap.Columns.Count - 1
            If topRow < ot Then result.Add sh.Range(sh.Cells(topRow, leftCol), sh.Cells(ot - 1, rightCol))
            If ob < bottomRow Then result.Add sh.Range(sh.Cells(ob + 1, leftCol), sh.Cells(bottomRow, rightCol))
            If leftCol < ol Then result.Add sh.Range(sh.Cells(ot, leftCol), sh.Cells(ob, ol - 1))
            If oright < rightCol Then result.Add sh.Range(sh.Cells(ot, oright + 1), sh.Cells(ob, rightCol))
        End If
    Next r
    Set SubtractRectangle = result
End Function

Public Sub PN_RefreshHundreds()
    If Not ActiveWorkbook Is Nothing Then PN_RefreshWorkbook ActiveWorkbook
End Sub

Public Sub PN_RefreshWorkbook(ByVal book As Workbook)
    If refreshing Then Exit Sub
    refreshing = True
    On Error GoTo Finish
    Dim nm As Name, target As Range, used As Range, c As Range, numbers As Range, constants As Range, formulas As Range
    For Each nm In book.Names
        If IsHundredsName(nm) Then
            Set target = Nothing
            On Error Resume Next
            Set target = nm.RefersToRange
            On Error GoTo Finish
            If Not target Is Nothing Then
                If Not target.Parent.ProtectContents Then
                    Set used = Application.Intersect(target, target.Parent.UsedRange)
                    If Not used Is Nothing Then
                        Set constants = Nothing: Set formulas = Nothing: Set numbers = Nothing
                        On Error Resume Next
                        Set constants = used.SpecialCells(xlCellTypeConstants, xlNumbers)
                        Set formulas = used.SpecialCells(xlCellTypeFormulas, xlNumbers)
                        On Error GoTo Finish
                        If Not constants Is Nothing Then Set constants = Application.Intersect(constants, used)
                        If Not formulas Is Nothing Then Set formulas = Application.Intersect(formulas, used)
                        If constants Is Nothing Then
                            Set numbers = formulas
                        ElseIf formulas Is Nothing Then
                            Set numbers = constants
                        Else
                            Set numbers = Application.Union(constants, formulas)
                        End If
                        If Not numbers Is Nothing Then
                            For Each c In numbers.Cells
                                RefreshHundredCell c
                            Next c
                        End If
                    End If
                End If
            End If
        End If
    Next nm
Finish:
    refreshing = False
End Sub

Private Sub RefreshHundredCell(ByVal cell As Range)
    Dim value As Variant, rounded As Double, text As String, code As String
    value = cell.Value2
    If IsError(value) Or IsEmpty(value) Then Exit Sub
    If VarType(value) = vbString Or VarType(value) = vbBoolean Then Exit Sub
    If Not IsNumeric(value) Then Exit Sub
    rounded = Application.WorksheetFunction.Round(CDbl(value), -2)
    If rounded = 0 Then
        code = """-"";""-"";""-"";@"
    Else
        text = Format$(Abs(rounded), "#,##0")
        code = """" & text & """;[Red]""-" & text & """;""-"";@"
    End If
    If cell.NumberFormat <> code Then cell.NumberFormat = code
End Sub

Public Sub PN_SelectColumnsToLastRow()
    On Error GoTo Failed
    If TypeName(Selection) <> "Range" Then Err.Raise vbObjectError + 703, , "Select worksheet cells first."
    Dim target As Range, area As Range, sh As Worksheet, selectedColumns As Object
    Dim i As Long, key As Variant, bottom As Long, maximum As Long, result As Range, part As Range, details As String, letter As String
    Set target = Selection: Set sh = target.Parent
    Set selectedColumns = CreateObject("Scripting.Dictionary")
    For Each area In target.Areas
        For i = area.Column To area.Column + area.Columns.Count - 1
            selectedColumns(CStr(i)) = True
        Next i
    Next area
    For Each key In selectedColumns.Keys
        bottom = PN_LastDataRow(sh.Columns(CLng(key)))
        letter = Split(sh.Cells(1, CLng(key)).Address, "$")(1)
        If bottom > maximum Then maximum = bottom
        If Len(details) Then details = details & "; "
        If bottom = 0 Then
            details = details & letter & ": empty"
            Set part = sh.Cells(1, CLng(key))
        Else
            details = details & letter & ":" & CStr(bottom)
            Set part = sh.Range(sh.Cells(1, CLng(key)), sh.Cells(bottom, CLng(key)))
        End If
        If result Is Nothing Then Set result = part Else Set result = Application.Union(result, part)
    Next key
    result.Select
    Application.DisplayStatusBar = True
    If maximum = 0 Then
        Application.StatusBar = "Last row: none | " & Left$(details, 1800)
    Else
        Application.StatusBar = "Last row: " & CStr(maximum) & " | " & Left$(details, 1800)
    End If
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Excel personal tools"
End Sub

Public Function PN_LastDataRow(ByVal column As Range) As Long
    Dim found As Range
    Set found = column.Find(What:="*", After:=column.Cells(1, 1), LookIn:=xlFormulas, _
        LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    If Not found Is Nothing Then PN_LastDataRow = found.Row
End Function

Public Sub PN_ClearStatusBar()
    Application.StatusBar = False
End Sub

Public Sub PN_DeleteBlankRows()
    On Error GoTo Failed
    Dim target As Range, count As Long
    Set target = SelectedCells()
    count = PN_DeleteBlankRowsFromRange(target)
    Application.StatusBar = CStr(count) & " entirely blank row(s) deleted."
    Exit Sub
Failed:
    MsgBox Err.Description, vbExclamation, "Excel personal tools"
End Sub

Public Function PN_DeleteBlankRowsFromRange(ByVal target As Range, Optional ByVal backupBase As String = "") As Long
    Dim sh As Worksheet, area As Range, rows As Object, commentRows As Object, key As Variant
    Dim last As Range, bottom As Long, i As Long, j As Long, rowList() As Long, count As Long
    Dim oldEvents As Boolean, oldScreen As Boolean, backup As String, item As Object, dynamicSheet As Object
    Set sh = target.Parent
    If sh.ProtectContents Then Err.Raise vbObjectError + 704, , "This worksheet is protected."
    Set last = sh.Cells.Find(What:="*", After:=sh.Cells(1, 1), LookIn:=xlFormulas, _
        LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    If last Is Nothing Then Exit Function
    Set rows = CreateObject("Scripting.Dictionary")
    Set commentRows = CreateObject("Scripting.Dictionary")
    For Each item In sh.Comments
        commentRows(CStr(item.Parent.Row)) = True
    Next item
    On Error Resume Next
    Set dynamicSheet = sh
    For Each item In dynamicSheet.CommentsThreaded
        commentRows(CStr(item.Parent.Row)) = True
    Next item
    On Error GoTo 0
    For Each area In target.Areas
        bottom = area.Row + area.Rows.Count - 1
        If bottom > last.Row Then bottom = last.Row
        For i = area.Row To bottom
            If Not rows.Exists(CStr(i)) Then rows.Add CStr(i), i
        Next i
    Next area
    If rows.Count = 0 Then Exit Function
    ReDim rowList(1 To rows.Count)
    For Each key In rows.Keys
        i = CLng(key)
        If Not commentRows.Exists(key) Then
            If Application.WorksheetFunction.CountA(sh.Rows(i)) = 0 Then
                If Not HasPopulatedMerge(sh, i) Then
                    count = count + 1: rowList(count) = i
                End If
            End If
        End If
    Next key
    If count = 0 Then Exit Function
    SortRowsDescending rowList, 1, count
    backup = MakeRowBackup(sh.Parent, backupBase)
    oldEvents = Application.EnableEvents: oldScreen = Application.ScreenUpdating
    On Error GoTo Failed
    Application.EnableEvents = False: Application.ScreenUpdating = False
    i = 1
    Do While i <= count
        bottom = rowList(i): j = i
        Do While j < count
            If rowList(j + 1) <> rowList(j) - 1 Then Exit Do
            j = j + 1
        Loop
        sh.Rows(CStr(rowList(j)) & ":" & CStr(bottom)).Delete
        PN_DeleteBlankRowsFromRange = PN_DeleteBlankRowsFromRange + j - i + 1
        i = j + 1
    Loop
    sh.Calculate
Finish:
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    PN_RefreshWorkbook sh.Parent
    Exit Function
Failed:
    Dim message As String
    message = Err.Description & vbCrLf & "A workbook copy was saved before deletion:" & vbCrLf & backup
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    Err.Raise vbObjectError + 705, , message
End Function

Private Sub SortRowsDescending(ByRef rows() As Long, ByVal first As Long, ByVal last As Long)
    Dim left As Long, right As Long, pivot As Long, temp As Long
    left = first: right = last: pivot = rows((first + last) \ 2)
    Do While left <= right
        Do While rows(left) > pivot: left = left + 1: Loop
        Do While rows(right) < pivot: right = right - 1: Loop
        If left <= right Then
            temp = rows(left): rows(left) = rows(right): rows(right) = temp
            left = left + 1: right = right - 1
        End If
    Loop
    If first < right Then SortRowsDescending rows, first, right
    If left < last Then SortRowsDescending rows, left, last
End Sub

Private Function HasPopulatedMerge(ByVal sh As Worksheet, ByVal row As Long) As Boolean
    Dim r As Range, cell As Range, flag As Variant
    flag = sh.Rows(row).MergeCells
    If Not IsNull(flag) Then
        If flag = False Then Exit Function
    End If
    Set r = Application.Intersect(sh.Rows(row), sh.UsedRange)
    If r Is Nothing Then Exit Function
    For Each cell In r.Cells
        If cell.MergeCells Then
            If Application.WorksheetFunction.CountA(cell.MergeArea) > 0 Then HasPopulatedMerge = True: Exit Function
        End If
    Next cell
End Function

Private Function MakeRowBackup(ByVal book As Workbook, ByVal base As String) As String
    Dim fso As Object, extension As String, path As String, folder As String, stem As String, i As Long
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Len(base) = 0 Then base = CreateObject("WScript.Shell").SpecialFolders("MyDocuments") & "\Personal Office Macro Backups"
    If Not fso.FolderExists(base) Then fso.CreateFolder base
    folder = base & "\Excel"
    If Not fso.FolderExists(folder) Then fso.CreateFolder folder
    Select Case book.FileFormat
        Case 50: extension = ".xlsb"
        Case 52: extension = ".xlsm"
        Case 56: extension = ".xls"
        Case 54: extension = ".xltx"
        Case 53: extension = ".xltm"
        Case Else: extension = ".xlsx"
    End Select
    stem = fso.GetBaseName(book.Name) & " - before blank rows - " & Format$(Now, "yyyymmdd-hhnnss")
    path = folder & "\" & stem & extension
    Do While fso.FileExists(path)
        i = i + 1: path = folder & "\" & stem & "-" & CStr(i) & extension
    Loop
    book.SaveCopyAs path
    MakeRowBackup = path
End Function

Public Sub PN_ShowStartupFolder()
    MsgBox "Excel's startup folder on this PC:" & vbCrLf & Application.StartupPath, vbInformation, "Personal Macro Workbook location"
End Sub
