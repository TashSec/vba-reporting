function Invoke-PastelOutlookStyles {
 param(
  [ValidateSet('Install','Restore')][string]$Mode,
  [string]$SourceFolder,
  [string]$TemplatesFolder,
  [string]$QuickStylesFolder,
  [bool]$RequireAppsClosed=$true
 )
 $ErrorActionPreference='Stop'
 if($RequireAppsClosed -and (Get-Process OUTLOOK,WINWORD -ErrorAction SilentlyContinue)){
  throw 'Save your work and close classic Outlook and Word, then run this option again.'
 }
 $SourceFolder=[IO.Path]::GetFullPath($SourceFolder)
 $TemplatesFolder=[IO.Path]::GetFullPath($TemplatesFolder)
 $QuickStylesFolder=[IO.Path]::GetFullPath($QuickStylesFolder)
 $target=Join-Path $TemplatesFolder 'NormalEmail.dotm'
 $quickTarget=Join-Path $QuickStylesFolder 'Pride email Style Set.dotx'
 $stateFile=Join-Path $SourceFolder 'Outlook installation state.json'
 $backupFolder=Join-Path $SourceFolder 'Backups'
 function SafeBackupPath([string]$name){
  $resolved=[IO.Path]::GetFullPath((Join-Path $backupFolder $name))
  if(-not $resolved.StartsWith(([IO.Path]::GetFullPath($backupFolder)+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected backup path.'}
  return $resolved
 }
 if($Mode -eq 'Restore'){
  if(-not (Test-Path -LiteralPath $stateFile)){throw 'There is no installation from this folder to restore.'}
  $state=Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
  if(-not $state.Installed){throw 'The previous settings have already been restored.'}
  if($state.Target -ne $target -or $state.QuickTarget -ne $quickTarget){throw 'This backup belongs to a different Windows profile.'}
  $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
  if(Test-Path -LiteralPath $target){Copy-Item -LiteralPath $target -Destination (Join-Path $backupFolder ('NormalEmail.pastel-retained-'+$stamp+'.dotm'))}
  if($state.NormalExisted){Copy-Item -LiteralPath (SafeBackupPath $state.NormalBackup) -Destination $target -Force}
  elseif(Test-Path -LiteralPath $target){Move-Item -LiteralPath $target -Destination (Join-Path $backupFolder ('NormalEmail.no-original-retained-'+$stamp+'.dotm'))}
  if($state.QuickExisted){Copy-Item -LiteralPath (SafeBackupPath $state.QuickBackup) -Destination $quickTarget -Force}
  elseif(Test-Path -LiteralPath $quickTarget){Move-Item -LiteralPath $quickTarget -Destination (Join-Path $backupFolder ('Pride email Style Set.retained-'+$stamp+'.dotx'))}
  $state.Installed=$false
  $state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stateFile -Encoding utf8
  return 'Your previous Outlook email defaults and Style Set have been restored. You can reopen Outlook.'
 }
 if(Test-Path -LiteralPath $stateFile){
  $old=Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
  if($old.Installed){throw 'These styles are already installed from this folder. Use Restore Outlook styles first if you want to reinstall.'}
 }
 $source=Join-Path $SourceFolder 'NormalEmail.dotm'
 $quickSource=Join-Path $SourceFolder 'Pride email Style Set.dotx'
 if(-not (Test-Path -LiteralPath $source) -or -not (Test-Path -LiteralPath $quickSource)){throw 'The supplied Outlook style files are missing. Keep the full template folder together.'}
 New-Item -ItemType Directory -Path $backupFolder,$TemplatesFolder,$QuickStylesFolder -Force | Out-Null
 $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
 $state=[pscustomobject]@{Installed=$false;Target=$target;QuickTarget=$quickTarget;NormalExisted=(Test-Path -LiteralPath $target);QuickExisted=(Test-Path -LiteralPath $quickTarget);NormalBackup=('NormalEmail.before-'+$stamp+'.dotm');QuickBackup=('Style Set.before-'+$stamp+'.dotx')}
 if($state.NormalExisted){Copy-Item -LiteralPath $target -Destination (SafeBackupPath $state.NormalBackup)}
 if($state.QuickExisted){Copy-Item -LiteralPath $quickTarget -Destination (SafeBackupPath $state.QuickBackup)}
 $word=$null;$doc=$null
 try {
  if(-not $state.NormalExisted){Copy-Item -LiteralPath $source -Destination $target}
  $word=New-Object -ComObject Word.Application
  $word.Visible=$false;$word.DisplayAlerts=0;$word.AutomationSecurity=3
  if($state.NormalExisted){
   foreach($name in @('Normal','Title','Heading 1','Heading 2','Heading 3','Caption','Subheading 1','Subheading 2','Captions','Pride Blue text','Pride Pink text','Pride Teal text','Pride Violet text','Pride Amber text','Pride Berry text','Pride Blue','Pride Pink','Pride Violet','Soft Pastel','Corporate')){
    $word.OrganizerCopy($source,$target,$name,0)
   }
  }
  $doc=$word.Documents.Open($target,$false,$false)
  $theme=Join-Path (Split-Path (Split-Path $SourceFolder -Parent) -Parent) 'Shared theme\Pride\Pride.thmx'
  if(Test-Path -LiteralPath $theme){$doc.ApplyDocumentTheme($theme)}
  foreach($name in @('Subheading 1','Subheading 2','Captions')){
   $style=$doc.Styles.Item($name);$style.QuickStyle=$true;$style.Font.Name='Tahoma'
  }
  $doc.SetDefaultTableStyle('Pride Blue',$false)
  $doc.Save();$doc.Close(0);$doc=$null
  $word.Quit(0);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word);$word=$null
  Copy-Item -LiteralPath $quickSource -Destination $quickTarget -Force
  $state.Installed=$true
  $state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stateFile -Encoding utf8
  return 'Installed. Reopen classic Outlook and create a new HTML email. In Format Text > Styles, expand the gallery to choose Subheading 1, Subheading 2 or Captions. Select a table to see the matching styles in Table Design.'
 }catch{
  if($null -ne $doc){try{$doc.Close(0)}catch{}}
  if($null -ne $word){try{$word.Quit(0)}catch{};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word);$word=$null}
  if($state.NormalExisted){Copy-Item -LiteralPath (SafeBackupPath $state.NormalBackup) -Destination $target -Force}
  if($state.QuickExisted){Copy-Item -LiteralPath (SafeBackupPath $state.QuickBackup) -Destination $quickTarget -Force}
  throw
 }finally{if($null -ne $word){$word.Quit(0);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word)}}
}
