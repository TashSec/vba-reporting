﻿param([ValidateSet('Install','Restore')][string]$Mode='Install')
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
. (Join-Path $PSScriptRoot 'Outlook styles engine.ps1')
try {
 $message=Invoke-PastelOutlookStyles -Mode $Mode -SourceFolder $PSScriptRoot -TemplatesFolder (Join-Path $env:APPDATA 'Microsoft\Templates') -QuickStylesFolder (Join-Path $env:APPDATA 'Microsoft\QuickStyles')
 [void][Windows.Forms.MessageBox]::Show($message,'Trans Pastel Outlook styles',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)
}catch{
 [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Trans Pastel Outlook styles',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Warning)
 exit 1
}
